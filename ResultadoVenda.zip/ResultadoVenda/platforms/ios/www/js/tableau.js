var viz;
var ticket;
		
	function initializeViz(workbookUrl,workbook,sheetName) {	
	
	    validarLogin();
		validarTempoSessao();
		
	    $.ajax({	    
		method : 'post',
		dataType: 'json',
		url: "https://api.apiluiza.com.br/v1/bireports/tickets",
		  headers: {
			"Authorization":"Bearer P1wFqTUbhfm059ZhoVSooBj2BsOt"
		  },
		  
		success : function(Result){
			
			ticket = Result.records[0].id;	 
			
				var placeholderDiv = document.getElementById("tableauViz"); 
				var navHeight = $(".navbar").height();
				var navWidth = $(".navbar").width();
				var docHeight = $(window).height();
				var divHeight = docHeight-navHeight;

				var options = {
					width: placeholderDiv.offsetWidth,
					height: divHeight-2,
					hideTabs: false,
					hideToolbar: true,
					onFirstInteractive: function () {
						workbook = viz.getWorkbook();
					}		
				};		         
			
				viz = new tableauSoftware.Viz(placeholderDiv, workbookUrl + "/trusted/"+ ticket + "/views/" + workbook + "/" + sheetName, options);
				
		 },
		 error: function (jqXHR, textStatus, errorThrown) {
		        		  if (jqXHR.status == 0) {
							$('#modalErroLogin').modal('show');
	                  } else {
						    $('#modalErroLogin').modal('show');
							} 
	    
	    } 		     
		});						
	
	}    		    	  				    				  
	   
	$(window).resize(function () {
	   var placeholderDiv = document.getElementById("tableauViz"); 
	   var navHeight = $(".navbar").height();
	   var docHeight = $(window).height();
	   var divHeight = docHeight-navHeight;
	   viz.setFrameSize(placeholderDiv.offsetWidth, divHeight-2);	     			
	});
				   
	function refreshViz() {
		viz.refreshDataAsync();
	};  		
