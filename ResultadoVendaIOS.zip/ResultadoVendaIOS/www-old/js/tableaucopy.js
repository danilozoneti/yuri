var viz;
var ticket;
var navHeight;
var navWidth;
var docHeight;
var divHeight;
var workbook;
var activeSheet;
var fstLoadPortrait = 0;
var fstLoadLandscape = 0;
var fstWidthPortrait;
var fstHeightPortrait;
var fstWidthLandscape;
var fstHeightLandscape;

    function initializeViz(workbookUrl,workbook,sheetName,orientation) {
        
        $.ajax({
               method : 'post',
               dataType: 'json',
               url: "https://api.apiluiza.com.br/v1/bireports/tickets",
               headers: {
                    "Authorization":"Bearer P1wFqTUbhfm059ZhoVSooBj2BsOt"
               },
               success : function (Result) {
               
                placeholderDiv = document.getElementById("tableauViz");

                console.log(orientation);
               
                if (orientation=='landscape') {

                    if (fstLoadLandscape == 0) {  
                         fstWidthLandscape = $(window).width();
                         navHeight = $(".navbar").height();
                         docHeight = $(window).height();
                         fstHeightLandscape = docHeight-navHeight;
                         fstLoadLandscape++;
                         //alert('Posicao: ' + orientation + ' Altura: '+ fstHeightLandscape + ' Largura: ' + fstWidthLandscape + ' fstLoad: ' + fstLoadLandscape);
                    }

                   var options = {
                     //width: 100,
                     //ßheight: 100,
                     hideTabs: false,
                     hideToolbar: true,
                     onFirstInteractive: function () {
                       workbook = viz.getWorkbook();
                       activeSheet = workbook.getActiveSheet();
                       alert(" ");
                       viz.setFrameSize(fstWidthLandscape,fstHeightLandscape);
                       //alert('Posicao: ' + orientation + ' Altura: '+ fstHeightLandscape + ' Largura: ' + fstWidthLandscape + ' fstLoad: ' + fstLoadLandscape);
                     }
                   };

                   //alert('Posicao: ' + orientation + ' Altura: '+ fstHeightLandscape + ' Largura: ' + fstWidthLandscape + ' fstLoad: ' + fstLoadLandscape);

                }
               
               if (orientation=='portrait') {

                   if (fstLoadPortrait == 0) {  
                       fstWidthPortrait = $(window).width();
                       navHeight = $(".navbar").height();
                       docHeight = $(window).height();
                       fstHeightPortrait = docHeight-navHeight;
                       fstLoadPortrait++;
                       //alert('Posicao: ' + orientation + ' Altura: '+ fstHeightPortrait + ' Largura: ' + fstWidthPortrait + ' fstLoad: ' + fstLoadPortrait);
                  }

                   var options = {
                     //width: 100,
                     //height: 100,
                     hideTabs: false,
                     hideToolbar: true,
                     onFirstInteractive: function () {
                       workbook = viz.getWorkbook();
                       activeSheet = workbook.getActiveSheet();
                       alert(" ");
                       viz.setFrameSize(fstWidthPortrait,fstHeightPortrait);
                       //alert('Posicao: ' + orientation + ' Altura: '+ fstHeightLandscape + ' Largura: ' + fstWidthLandscape + ' fstLoad: ' + fstLoadLandscape);
                     }
                   };

               }
               
               viz = new tableauSoftware.Viz(placeholderDiv, workbookUrl + "/trusted/"+ Result.records[0].id + "/views/" + workbook + "/" + sheetName, options);
               
               },
               error: function (jqXHR, textStatus, errorThrown) {
               console.log("erro");
                 if (jqXHR.status == 0) {
                   $('#modalErroLogin').modal('show');
                 } else {
                   $('#modalErroLogin').modal('show');
                 }
               }
               
        });
        
        };

        function dispose () {
           viz.dispose();
        };

	$(window).resize(function () {
	   navHeight = $(".navbar").height();
     navWidth = $(".navbar").width();
	   docHeight = $(window).height();
	   divHeight = docHeight-navHeight;
	   viz.setFrameSize(navWidth+2, divHeight);
    });
