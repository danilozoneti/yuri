function tempoLogin() {	

	var now = new Date().getTime();
	var result = window.localStorage.getItem("timem");
	var param = 3600000
	var total = (Number(result) + Number(param)) - now;
	
	if(result == null){
		window.localStorage.setItem("timem", now);
		window.location.href = "apresentacao.html"; }
	else{				    	
		if(total > 0){
			}
		else{
			window.location.href = "index_erro.html";
		}
	}
	
}	