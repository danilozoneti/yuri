var viz;
var ticket;
		
	function initializeViz(workbookUrl,workbook,sheetName) {	
	
	    validarLogin();
		validarTempoSessao();
		
	    $.ajax({	    
		method : 'post',
		dataType: 'json',
		url: "https://api.apiluiza.com.br/v1/bireports/tickets",
		  headers: {
			"Authorization":"Bearer P1wFqTUbhfm059ZhoVSooBj2BsOt"
		  },
		  
		success : function(Result){
			
			ticket = Result.records[0].id;	 
			
				var placeholderDiv = document.getElementById("tableauViz"); 
				var navWidth = $(".navbar").width();
				var navHeight = $(".navbar").innerHeight();
				var tabHeigth = $("#tabela").innerHeight();				
				var docHeight = $(window).innerHeight();
				var divHeight = docHeight-(navHeight+tabHeigth+5);

				//console.log($(".navbar").innerHeight() + $("#tabela").innerHeight());

				var options = {
					//width: navWidth,
					//height: divHeight,
					hideTabs: false,
					hideToolbar: true,
					onFirstInteractive: function () {
						workbook = viz.getWorkbook();
					}		
				};		         
			
				viz = new tableauSoftware.Viz(placeholderDiv, workbookUrl + "/trusted/"+ ticket + "/views/" + workbook + "/" + sheetName + '?:render=false', options);
				console.log(workbookUrl + "/trusted/"+ ticket + "/views/" + workbook + "/" + sheetName + '?:render=false');
				
		 },
		 error: function (jqXHR, textStatus, errorThrown) {
		        		  if (jqXHR.status == 0) {
							$('#modalErroLogin').modal('show');
	                  } else {
						    $('#modalErroLogin').modal('show');
							} 
	    
	    } 		     
		});						
	
	}    		    	  				    				  
	   
	$(window).resize(function () {
	   var placeholderDiv = document.getElementById("tableauViz");
	   var navWidth = $(".navbar").width();
	   var navHeight = $(".navbar").innerHeight();
	   var tabHeigth = $("#tabela").innerHeight();				
	   var docHeight = $(window).innerHeight();
	   var divHeight = docHeight-(navHeight+tabHeigth+5);
	   viz.setFrameSize(navWidth, divHeight);	     			
	});
				   
	function refreshViz() {
		viz.refreshDataAsync();
	};  		
