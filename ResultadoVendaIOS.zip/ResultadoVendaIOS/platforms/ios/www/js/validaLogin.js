function validarLogin() {	

	var cookie_usuario = window.localStorage.getItem("usuario");
	
		if (cookie_usuario == null){
			window.location.href = "index.html";  
		} 		
			
}					

function validarTempoSessao() {
	
	var cookie_sessao = window.localStorage.getItem("sessao");
	var agora = new Date().getTime();
	var tempo_sessao = 43200000;
	var tempo_logado = (Number(cookie_sessao) + Number(tempo_sessao)) - agora;			
	
		if (tempo_logado < 0) {
			window.location.href = "index_erro.html"; 
		}
						
	
}	
